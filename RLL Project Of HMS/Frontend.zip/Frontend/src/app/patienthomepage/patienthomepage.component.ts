import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patienthomepage',
  templateUrl: './patienthomepage.component.html',
  styleUrls: ['./patienthomepage.component.css']
})
export class PatienthomepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  Logout(){
    sessionStorage.clear();
    
  }
}
